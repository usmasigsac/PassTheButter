SERVICE = "test"
import requests
import sys

def pwn(ip):
    print(ip)
    with open('output.txt', 'w') as out:
        out.write(requests.get("https://www.google.com").text)
    return requests.get("https://www.google.com").text


if __name__ == '__main__':
    pwn(sys.argv(1))