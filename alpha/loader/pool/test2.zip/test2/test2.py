SERVICE = "test"

def pwn():
	print("pwnd!")